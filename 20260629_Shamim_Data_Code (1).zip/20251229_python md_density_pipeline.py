#!/usr/bin/env python

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error

# Create a directory for plots if it doesn't exist
if not os.path.exists('plots'):
    os.makedirs('plots')

# ---------------------------------------------------------
# Stratified Split Function
# ---------------------------------------------------------
def stratified_split(df, stratify_col, test_size=0.2, n_bins=10, random_state=42):
    col = df[stratify_col]

    if pd.api.types.is_numeric_dtype(col):
        df["_strat_bin"] = pd.qcut(col, q=n_bins, duplicates='drop')
        stratify_vals = df["_strat_bin"]
    else:
        stratify_vals = col

    train_df, test_df = train_test_split(
        df,
        test_size=test_size,
        random_state=random_state,
        stratify=stratify_vals
    )

    if "_strat_bin" in df.columns:
        train_df = train_df.drop(columns="_strat_bin")
        test_df = test_df.drop(columns="_strat_bin")

    return train_df, test_df


# ---------------------------------------------------------
# Plot helper functions for Ep_Si-O datasets
# ---------------------------------------------------------
def plot_pred_density(df, pred, epsilon=3.0, filename_suffix=""):
    df = df.copy()
    df["pred_density"] = pred
    df_eps = df[df["Ep_Si-O"] == epsilon]

    # Sort for cleaner line plots
    df_eps = df_eps.sort_values(by="Chunk")

    x = df_eps["Chunk"].values
    gt_y = df_eps["Density"].values
    pred_y = df_eps["pred_density"].values

    plt.figure(figsize=(10, 6))
    plt.plot(x, gt_y, label="Ground Truth Density", color="blue")
    plt.plot(x, pred_y, label="Predicted Density", color="orange")
    plt.xlabel("Chunk")
    plt.ylabel("Density")
    plt.title(f"Density Prediction at Ep_Si-O = {epsilon}")
    plt.legend()
    plt.tight_layout()
    
    # SAVE instead of show
    fname = f"plots/density_pred_eps{epsilon}_{filename_suffix}.png"
    plt.savefig(fname)
    plt.close()
    print(f"Saved plot: {fname}")


def plot_pred_density_combined(df, gt, pred, epsilon=3.0, filename_suffix=""):
    df = df.copy()
    df["pred_density"] = pred
    df["Density"] = gt
    df_eps = df[df["Ep_Si-O"] == epsilon]

    # Sort for cleaner line plots
    df_eps = df_eps.sort_values(by="Chunk")

    x = df_eps["Chunk"].values
    gt_y = df_eps["Density"].values
    pred_y = df_eps["pred_density"].values

    plt.figure(figsize=(10, 6))
    plt.plot(x, gt_y, label="Ground Truth Density", color="blue")
    plt.plot(x, pred_y, label="Predicted Density", color="orange")
    plt.xlabel("Chunk")
    plt.ylabel("Density")
    plt.title(f"Density Prediction at Ep_Si-O = {epsilon}")
    plt.legend()
    plt.tight_layout()
    
    # SAVE instead of show
    fname = f"plots/density_combined_eps{epsilon}_{filename_suffix}.png"
    plt.savefig(fname)
    plt.close()
    print(f"Saved plot: {fname}")


def main():
    # =====================================================
    # PART 1: Den_data_Pad.xlsx -> stratified split + RF
    # =====================================================
    print("=== PART 1: Den_data_Pad.xlsx ===")

    try:
        df = pd.read_excel("Den_data_Pad.xlsx")
        
        # Scale density
        df["density/number"] = df["density/number"] * (10**3)

        # Stratified train–test split
        train, test = stratified_split(df, stratify_col="co_ord", test_size=0.2)
        print("Train shape:", train.shape)
        print("Test shape :", test.shape)

        x_train = train[['Channel_w', 'co_ord']]
        y_train = train["density/number"]
        x_test = test[['Channel_w', 'co_ord']]
        y_test = test["density/number"]

        # -----------------------------------------------------
        # Random Forest
        # -----------------------------------------------------
        model = RandomForestRegressor(n_estimators=200, random_state=42, n_jobs=-1)
        model.fit(x_train, y_train)
        
        y_train_pred = model.predict(x_train)
        y_test_pred  = model.predict(x_test)

        r2_train = r2_score(y_train, y_train_pred)
        r2_test  = r2_score(y_test,  y_test_pred)

        # PLOT 1: Train/Test Scatter
        plt.figure(figsize=(7, 6))
        plt.scatter(y_train, y_train_pred, alpha=0.6, label=f"Train (R²={r2_train:.3f})", color="blue")
        plt.scatter(y_test,  y_test_pred,  alpha=0.8, label=f"Test (R²={r2_test:.3f})",  color="red")
        
        y_min = min(y_train.min(), y_test.min())
        y_max = max(y_train.max(), y_test.max())
        plt.plot([y_min, y_max], [y_min, y_max], 'k--')
        plt.xlabel("Actual density/number")
        plt.ylabel("Predicted density/number")
        plt.title("Random Forest Regression: Predicted vs Actual")
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        
        plt.savefig("plots/rf_actual_vs_pred.png")
        plt.close()
        print("Saved plot: plots/rf_actual_vs_pred.png")

        # PLOT 2: Density Distribution (No Extrapolation)
        plt.figure(figsize=(7, 5))
        plt.scatter(train["co_ord"], train["density/number"], color="blue", alpha=0.6, label="Train")
        plt.scatter(test["co_ord"],  test["density/number"],  color="red", alpha=0.8, label="Test")
        plt.xlabel("Coordinate")
        plt.ylabel("Density / Number")
        plt.title("Density Distribution (Stratified Split)")
        plt.grid(True, alpha=0.2)
        plt.legend()
        plt.tight_layout()
        
        plt.savefig("plots/density_distribution_stratified.png")
        plt.close()
        print("Saved plot: plots/density_distribution_stratified.png")

        # PLOT 3: Density Distribution (Manual Split/Extrapolation)
        train_ext = df[(df["Channel_w"] == 2.403) | (df["Channel_w"] == 1.602)]
        test_ext  = df[(df["Channel_w"] == 4.23)  | (df["Channel_w"] == 3.204)]
        
        # Sort test_ext for line plotting
        test_ext = test_ext.sort_values(by="co_ord")

        plt.figure(figsize=(7, 5))
        plt.scatter(train_ext["co_ord"], train_ext["density/number"], color="blue", alpha=0.4, label="Train")
        
        # Loop to plot separate lines for different widths
        for width in test_ext["Channel_w"].unique():
            subset = test_ext[test_ext["Channel_w"] == width]
            plt.plot(subset["co_ord"], subset["density/number"], color="red", alpha=0.8, linewidth=2, label=f"Test (w={width})")

        plt.xlabel("Coordinate")
        plt.ylabel("Density / Number")
        plt.title("Density Distribution (Manual Split)")
        plt.grid(True, alpha=0.3)
        plt.legend()
        plt.tight_layout()
        
        plt.savefig("plots/density_distribution_manual.png")
        plt.close()
        print("Saved plot: plots/density_distribution_manual.png")

    except Exception as e:
        print(f"Skipping Part 1 (Den_data_Pad.xlsx issue): {e}")

    # =====================================================
    # PART 2: train_set.csv & test_set.csv -> Combined RF
    # =====================================================
    print("\n=== PART 2: train_set.csv & test_set.csv ===")

    try:
        train_data = pd.read_csv('train_set.csv')
        test_data  = pd.read_csv('test_set.csv')

        # Model 2 on original split
        X_train = train_data.drop(columns=['Density'])
        y_train = train_data['Density']
        X_test  = test_data.drop(columns=['Density'])
        y_test  = test_data['Density']

        model2 = RandomForestRegressor(n_estimators=100, random_state=42)
        model2.fit(X_train, y_train)
        y_pred2 = model2.predict(X_test)

        # Plot predictions on original test set
        plot_pred_density(test_data, y_pred2, epsilon=3.0, filename_suffix="original_split")
        plot_pred_density(test_data, y_pred2, epsilon=2.0, filename_suffix="original_split")

        # Combine and Resplit
        combine_df = pd.concat([train_data, test_data], ignore_index=True)
        X = combine_df.drop(columns=['Density'])
        y = combine_df['Density']

        # Train on full combined data or new split? 
        # (Your logic trained on 60% of combined, but predicted on 100% of combined)
        # We will follow your logic: Train on 60%, Predict on 100%
        X_train_comb, X_test_comb, y_train_comb, y_test_comb = train_test_split(X, y, test_size=0.4, random_state=42)
        
        model_comb = RandomForestRegressor(n_estimators=100, random_state=42)
        model_comb.fit(X_train_comb, y_train_comb)

        y_full_pred = model_comb.predict(X)
        
        # Plot predictions for multiple epsilons on combined data
        for epsilon in [0.5, 1.1, 3.0, 4.0]:
            plot_pred_density_combined(combine_df, y, y_full_pred, epsilon=epsilon, filename_suffix="combined_rf")

        # PLOT: Feature Importance
        if hasattr(model_comb, 'feature_importances_'):
            importances = model_comb.feature_importances_
            feature_names = X.columns
            indices = np.argsort(importances)[::-1]

            plt.figure(figsize=(10, 6))
            plt.title("Feature Importances (Combined Model)")
            plt.bar(range(X.shape[1]), importances[indices], align="center")
            plt.xticks(range(X.shape[1]), feature_names[indices], rotation=90)
            plt.xlim([-1, X.shape[1]])
            plt.tight_layout()
            
            plt.savefig("plots/feature_importance.png")
            plt.close()
            print("Saved plot: plots/feature_importance.png")

    except Exception as e:
        print(f"Skipping Part 2 (CSV files issue): {e}")

if __name__ == "__main__":
    main()