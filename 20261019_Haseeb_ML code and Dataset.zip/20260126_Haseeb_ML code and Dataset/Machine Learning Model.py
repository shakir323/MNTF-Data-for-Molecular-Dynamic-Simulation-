# ======================================================
#   ML MODEL ON MD THERMAL CONDUCTIVITY DATA
# ======================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.pipeline import Pipeline
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

# ======================================================
#   Loading and inspecting the MD Data
# ======================================================

data_file = "Dataset.csv"   # my file name
df = pd.read_csv(data_file)

print("Data shape:", df.shape)
print(df)                     # normal printing in PyCharm

plt.figure(figsize=(7,5))
plt.scatter(df["T (kelvin)"], df["k (W/mK)"], s=40)
plt.xlabel("Temperature T (K)",fontsize=18, fontweight="bold")
plt.ylabel("MD κ (W/m·K)",fontsize=18, fontweight="bold")
plt.title("MD Green–Kubo Results",fontsize=18, fontweight="bold")
#plt.grid(True)

# ======================================================
#   Preparing X and Y data in train/test split
# ======================================================
X = df[["T (kelvin)"]].values
y = df["k (W/mK)"].values

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print("Train size:", X_train.shape[0])
print("Test size:", X_test.shape[0])

# ======================================================
#   Defining the Random Forest Model
# ======================================================
from sklearn.ensemble import RandomForestRegressor

rf_model = RandomForestRegressor(
    n_estimators=2000,
    max_depth=None,
    random_state=42,
    verbose = 1  # Set to 1 to see training progress
)

# ======================================================
#   Training my Model
# ======================================================
models = {
    "RandomForest": rf_model
}

results = []

for name, model in models.items():
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    r2  = r2_score(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))

    results.append({"Model": name, "R2": r2, "MAE": mae, "RMSE": rmse})
    print(f"\n=== {name} ===")
    print(f"R²   : {r2:.4f}")
    print(f"MAE  : {mae:.4f} W/mK")
    print(f"RMSE : {rmse:.4f} W/mK")

res_df = pd.DataFrame(results)
print("\nModel Performance Table:")
print(res_df)

# ======================================================
#   Plotting MD and ML Model
# ======================================================
T_grid = np.linspace(df["T (kelvin)"].min(), df["T (kelvin)"].max(), 50).reshape(-1, 1)
T_grid_flat = T_grid.ravel()   # flatten for plotting

plt.figure(figsize=(7,5))

# MD data as scatter
plt.scatter(df["T (kelvin)"], df["k (W/mK)"], s=80, alpha=0.7,color="orange", label="MD (Green–Kubo)")

# ML predictions as star markers
for name, model in models.items():
    k_pred = model.predict(T_grid)
    plt.scatter(T_grid_flat, k_pred, marker="*", s=50, label=f"ML: {name}")  # ★ stars here

plt.xlabel("Temperature T (K)",fontsize=18, fontweight="bold")
plt.ylabel("Thermal Conductivity κ (W/m·K)",fontsize=18, fontweight="bold")
plt.title("MD vs ML Thermal Conductivity Models",fontsize=18, fontweight="bold")
#plt.grid(True)
plt.legend()
plt.tight_layout()

# ======================================================
#   Save MD data + ML predictions to CSV
# ======================================================

# 1) Add one column per ML model with predictions on the full dataset
for name, model in models.items():
    col_name = f"k_ML_{name}"      # e.g., "k_ML_RandomForest"
    df[col_name] = model.predict(df[["T (kelvin)"]].values)

# 2) Side-by-side histograms: MD vs ML κ (full dataset)
k_md = df["k (W/mK)"]
k_ml = df["k_ML_RandomForest"]     # column created just above

# Use same x-range for fair comparison
k_min = min(k_md.min(), k_ml.min())
k_max = max(k_md.max(), k_ml.max())

# ======================================================
#   Bar chart: MD vs ML on test samples
# ======================================================

# Get predictions on the test set
rf = models["RandomForest"]
y_pred_test = rf.predict(X_test)

# Choose how many test samples to display (e.g., first 12)
N = 5
indices = np.arange(N)

plt.figure(figsize=(10, 5))

# ML prediction bars (left)
plt.bar(indices - 0.2, y_pred_test[:N], width=0.4, label="ML Prediction")

# MD actual bars (right)
plt.bar(indices + 0.2, y_test[:N], width=0.4, label="MD Actual")

# 3) Save to a new CSV file
output_file = "Dataset with ML.csv"
df.to_csv(output_file, index=False)

print(f"\nSaved MD + ML data to: {output_file}")
print(df.head())

plt.xlabel("Test Samples",fontsize=18, fontweight="bold")
plt.ylabel("Thermal Conductivity κ (W/m·K)",fontsize=18, fontweight="bold")
plt.title("Thermal Conductivity: MD vs ML (RandomForest)",fontsize=18, fontweight="bold")
plt.xticks(indices, [f"Sample {i+1}" for i in range(N)],fontsize=16)
#rotation=45
plt.legend()
#plt.grid(axis="y")
plt.tight_layout()
plt.ioff()
plt.show(block=True)



